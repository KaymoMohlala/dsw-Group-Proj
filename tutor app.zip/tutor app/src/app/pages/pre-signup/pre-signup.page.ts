import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-signup',
  templateUrl: './pre-signup.page.html',
  styleUrls: ['./pre-signup.page.scss'],
})
export class PreSignupPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
